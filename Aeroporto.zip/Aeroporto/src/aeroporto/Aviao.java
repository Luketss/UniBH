package aeroporto;


public class Aviao {
    
    private int codigo;
    private String modelo;
    private int lugares;
    private Tripulacao tripulacao;
    
    public Aviao(int codigo, String modelo, int lugares, Tripulacao tripulacao){
        this.codigo = codigo;
        this.modelo = modelo;
        this.lugares = lugares;
        this.tripulacao = tripulacao;
    }
    
}
