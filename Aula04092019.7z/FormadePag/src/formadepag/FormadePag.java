package formadepag;

import java.util.Scanner;

public class FormadePag {
 
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        double produto = 0, resultado = 0;
        int pagamento = 1;

        while( pagamento != 0){   
        System.out.println("Qual o valor do produto: ");
        produto = entrada.nextDouble();
        
        if(produto == 0){
            System.out.println("Não tem pagamento...");
            break;
        }
        
        System.out.println(" 1.	Desconto de 10% ");
        System.out.println(" 2. Desconto de 20% ");
        System.out.println(" 3. Adicionar 30% de juros ");
        System.out.println(" 4. Adicionar 60% de juros ");
        
        System.out.println("Qual a forma de pagamento: ");
        pagamento = entrada.nextInt();
        
        if(pagamento == 1){
            resultado = produto * 0.10;
            produto = produto - resultado;
            System.out.println("Resultado: " + produto);
        }
        
        else if(pagamento == 2){
            resultado = produto * 0.20;
            produto = produto - resultado;
            System.out.println("Resultado: " + produto);
        }
        
        else if(pagamento == 3){
            resultado = produto * 0.30;
            produto = produto + resultado;
            System.out.println("Resultado: " + produto);
        }
        
        else if(pagamento == 4){
            resultado = produto * 0.60;
            produto = produto + resultado;
            System.out.println("Resultado: " + produto);
        }
        else if(pagamento == 0){
            System.out.println("DESLIGANDO........");
            break;
        }
        else{
            System.out.println("Entrada Inválida");
        }
      }
    }
    
}
