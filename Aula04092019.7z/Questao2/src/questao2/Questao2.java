package questao2;

import java.util.Scanner;

public class Questao2 {

    
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int soma = 1;
        int x;
        
        System.out.println("Insira um valor: ");
        x = entrada.nextInt();
        
        for( int i = 2; i <= x; i++)
        {
        soma += i;
        }
        
        System.out.println("é igual a " + soma);
        
    }
    
}
