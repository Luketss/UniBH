package questao1;

import java.util.Scanner;

public class Questao1 {

    
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int x, funcao = 0;
        
        System.out.println("Digite um valor para x: ");
        x = entrada.nextInt(); 
        funcao = x + 1;
        
        System.out.println("Resultado: " + funcao);
        
    }
    
}
