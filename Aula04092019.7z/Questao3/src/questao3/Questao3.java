package questao3;

import java.util.Scanner;

public class Questao3 {

    
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int soma = 1;
        int valor, func = 0, x = 0;
        
        System.out.println("Insira um valor: ");
        valor = entrada.nextInt();
        
        for( int i = 2; i <= valor; i++)
        {
        soma *= i;
        x = valor + valor;
        func = soma / x;
        }
        
        System.out.println("é igual a " + func);
        
    }
    
}
