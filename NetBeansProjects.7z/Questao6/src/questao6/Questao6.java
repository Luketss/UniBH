package questao6;

import java.util.Scanner;

public class Questao6 {

    
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        double quadrado1 = 0, quadrado2 = 0, quadrado3 = 0, area1 = 0, area2 = 0, area3 = 0;
        
        System.out.println("Digite o valor do primeiro quadrado: ");
        quadrado1 = entrada.nextDouble();
        
        System.out.println("Digite o valor do segundo quadrado: ");
        quadrado2 = entrada.nextDouble();
        
        System.out.println("Digite o valor do terceiro quadrado: ");
        quadrado3 = entrada.nextDouble();
        
        area1 = quadrado1 * quadrado1;
        
        area2 = quadrado2 * quadrado2;
        
        area3 = quadrado3 * quadrado3;
                
        if(area1 > area2 && area1 > area3){
            System.out.println("O maior quadrado é o de lado: " + quadrado1);
        }
        
        if(area2 > area1 && area2 > area3){
            System.out.println("O maior quadrado é o de lado: " + quadrado2);
        }
        
        if(area3 > area2 && area3 > area1){
            System.out.println("O maior quadrado é o de lado: " + quadrado3);
        }   
                
    }
    
}
