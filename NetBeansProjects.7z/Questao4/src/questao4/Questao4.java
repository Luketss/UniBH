package questao4;

import java.util.Scanner;

public class Questao4 {

    public static void main(String[] args) {
       Scanner entrada = new Scanner(System.in);
       
       int lado = 0, perimero = 0, altura = 0;
       
        System.out.println("Digite o valor para o lado do quadrado");
        lado = entrada.nextInt();
        
        perimero = lado * 4;
        
        altura = lado * lado;
        
        System.out.println("O perimetro é: " + perimero);
        
        System.out.println("A altura é: " + altura);
       
    }
    
}
