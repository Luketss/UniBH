package questao5;

import java.util.Scanner;

public class Questao5 {


    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        double area, pi = 3.1415, raio, result; 
        
        System.out.println("Insira o valor do raio: ");
        raio = entrada.nextDouble();
        
        result = Math.pow(raio, 2);
        
        area = pi * result;
        
        System.out.println("Resultado: " + area);
        
    }
    
}
