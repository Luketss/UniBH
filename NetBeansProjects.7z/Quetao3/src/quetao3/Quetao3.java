package quetao3;

import java.util.Scanner;

public class Quetao3 {
   
    public static void main(String[] args) {
       
        Scanner entrada = new Scanner(System.in);
        
        int cont = 0;
        
        while(cont < 10000){
            
            if(cont % 2 != 0){
            System.out.println("Ímpar: " + cont);
            }
            cont++;
        }
        
        
        
    }
    
}
