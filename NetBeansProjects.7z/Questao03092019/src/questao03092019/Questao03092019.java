package questao03092019;
import java.util.Scanner;
public class Questao03092019 {

    
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        float num, produto = 0, cont = 0;
        
        while(cont <= 100000){
            System.out.println("VOCÊ ESTÁ FERRADO ESCREVA UM NÚMERO: ");
            num = entrada.nextFloat();
            
            produto = produto * num;
        }
        
        System.out.println("O valor foi: " + produto);
        
        
        
        
    }
    
}
