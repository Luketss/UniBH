package questao2;

import java.util.Scanner;

public class Questao2 {
   
    public static void main(String[] args) {
       
        Scanner entrada = new Scanner(System.in);
        
        int cont = 0;
        
        while(cont < 10000){
            
            if(cont % 2 == 0){
            System.out.println("Pares: " + cont);
            }
            cont++;
        }
        
        
        
    }
    
}
