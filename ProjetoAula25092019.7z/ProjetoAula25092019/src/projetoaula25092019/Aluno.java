
package projetoaula25092019;

public class Aluno {
    
    public String nome;
    public Disciplina dis[];
    public Endereco end;
    
    public Aluno (String nomePar, Disciplina disPar[], Endereco endPar){
    
        this.nome = nomePar;
        this.dis = disPar;
        this.end = endPar;
    }
}

