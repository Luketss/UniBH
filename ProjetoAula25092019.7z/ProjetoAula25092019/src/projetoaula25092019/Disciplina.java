package projetoaula25092019;


public class Disciplina {
    
    public String descricao;
    public float nota;
    
    public Disciplina( String descricaoPar, float notaPar){
        
        this.descricao = descricaoPar;
        this.nota = notaPar;
        
    }

    Disciplina() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
