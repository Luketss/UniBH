package projetoaula25092019;


public class Endereco {
    
    public String bairro;
    public String rua;
    public int numero;
    
    public Endereco( String bairroPar, String ruaPar, int numeroPar){
        this.bairro = bairroPar;
        this.rua = ruaPar;
        this.numero = numeroPar;
    }
    
}
