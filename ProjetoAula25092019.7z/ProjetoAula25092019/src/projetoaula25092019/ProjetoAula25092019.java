package projetoaula25092019;

import java.util.Scanner;

public class ProjetoAula25092019 {

    
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        Disciplina dis = new Disciplina();
        dis.descricao = "asdasddsasd";
        
        System.out.println("Digite o valor da nota do aluno: ");
        dis.nota = entrada.nextFloat();
    }
    
}
