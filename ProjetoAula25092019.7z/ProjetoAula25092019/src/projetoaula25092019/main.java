package projetoaula25092019;


public class main {
    
    public static void main(String[] args) {
    Disciplina dispa = new Disciplina ("Teoria 1", 80);
    Disciplina disp2 = new Disciplina ("Matéria2", 100);
    Disciplina dis[] = new Disciplina[2];
    
    dis[0] = dispa; 
    dis[1] = disp2;
    
    Endereco endA = new Endereco ("bairro", "rua" , 213);
    
    Aluno a1 = new Aluno("Lucas", dis, endA);
    
        System.out.println("Valor alocado no nome: " + a1.nome);
        System.out.println(a1.dis[0].descricao);
        
    }
    
}
