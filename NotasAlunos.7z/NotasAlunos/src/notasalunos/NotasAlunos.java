package notasalunos;

import java.util.Scanner;

public class NotasAlunos {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        String nome[] = new String[5];
        double notasPort[] = new double[5];
        double notasMat[] = new double[5];
        double mediaPort = 0, mediaMat = 0, maiorPort = 0, menorMat = 100;
        String alunoMaiorPort = "a", alunoMenorMat = "a";
        
        for( int i = 0; i < 5; i++ ){
            
            System.out.println("Digite o nome do aluno " + i);
            nome[i] = entrada.nextLine(); 
            
            System.out.println("Digite a nota de português do aluno " + nome[i]);
            notasPort[i] = entrada.nextDouble();
            
            System.out.println("Digite a nota de matemática do aluno " + nome[i]);
            notasMat[i] = entrada.nextDouble(); entrada.nextLine();
            
            mediaPort += notasPort[i];
            mediaMat += notasMat[i];
            
            if( notasPort[i] > maiorPort ){
                maiorPort = notasPort[i];
                alunoMaiorPort = nome[i];
                
            }
            
            if( notasMat[i] < menorMat ){
                menorMat = notasMat[i];
                alunoMenorMat = nome[i];
            }
        }
        
        System.out.println("O valor da média das notas de português é: " + mediaPort);
        System.out.println("O valor da média das notas de matemática é: " + mediaMat);
        System.out.println("O aluno com a MAIOR nota de Português é o " + alunoMaiorPort + " Com o total de " + maiorPort);
        System.out.println("O aluno com a MENOR nota de Matemática é o " + alunoMenorMat + " Com o total de " + alunoMenorMat);
        
        
    }
    
}
