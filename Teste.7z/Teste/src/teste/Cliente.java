/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package teste;

/**
 *
 * @author 11916079
 */
public class Cliente {
    private String nome;
    private String endereco;
    private String sexo;
    private double rendaMensal;

    public Cliente(String nome, String endereco, String sexo, double rendaMensal) {

        this.nome = nome;
        this.endereco = endereco;
        this.sexo = sexo;
        this.rendaMensal = rendaMensal;

    }

    public String getNome() {
        return (this.nome);
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getEndereco(){
        return (this.endereco);
    }
    
    public void setEndereco(String endereco){
        this.endereco = endereco;
    }
    
    public String getSexo(){
        return(this.sexo);
    }
    
    public void setSexo(String sexo){
        this.sexo = sexo;
    }
    
    public double getRendaMensal(){
        return(this.rendaMensal);
    }
    
    public void setRendaMensal(double rendaMensal){
        this.rendaMensal = rendaMensal;
    }

}
