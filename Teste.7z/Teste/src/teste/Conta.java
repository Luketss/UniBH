/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package teste;

/**
 *
 * @author 11916079
 */
public class Conta {
    private int numero;
    private Cliente cliente;
    private double saldo;
    private double limite;
    private double saque;
    
    public Conta( int numero, Cliente cliente, double saldo, double limite, double saque){
        this.numero = numero;
        this.cliente = cliente;
        this.saldo = saldo;
        this.limite = limite;
        this.saque = saque;
    }
    
    public int getConta(){
        return this.numero;
    }
    
    public void setConta(int numero){
        this.numero = numero;
    }
    
    public Cliente getCliente(){
        return this.cliente;
    }
    
    public void setCliente(Cliente cliente){
        this.cliente = cliente;
    }
    
    public double getSaldo(){
        return this.saldo;
    }
    
    public void setSaldo(double saldo){
        this.saldo = saldo;
    }
    
    public double getLimite(){
        return this.limite;
    }
    
    public void setLimite(double limite){
        this.limite = limite;
    }
    
    public double getSaque(){
        return this.saque;
    }
    
    public void setSaque(int saque){
        this.saque = saque;
    }
}
