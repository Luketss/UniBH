package notasalunos;

import java.util.Scanner;

public class NotasAlunos {
    

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
  
        String nome[] = new String[5];
        double notasPort[] = new double[5];
        double notasMat[] = new double[5];
        double mediaPort = 0, mediaMat = 0, menorPort = 0, maiorMat = 100;
        String alunoMenorPort = "a", alunoMaiorMat = "a";
        
        for( int i = 0; i < 5; i++ ){
            
            System.out.println("Digite o nome do aluno " + i);
            nome[i] = entrada.nextLine().trim(); 
            
            System.out.println("Digite a nota de português do aluno " + nome[i]);
            notasPort[i] = entrada.nextDouble();
            
            System.out.println("Digite a nota de matemática do aluno " + nome[i]);
            notasMat[i] = entrada.nextDouble(); entrada.nextLine();
            
            mediaPort += notasPort[i];
            mediaMat += notasMat[i];
            
            if(  notasMat[i] > maiorMat ){
                maiorMat = notasPort[i];
                alunoMaiorMat = nome[i];
                
            }
            
            if( notasPort[i] < menorPort ){
                menorPort = notasMat[i];
                alunoMenorPort = nome[i];
            }
        }
        
        System.out.println("O valor da média das notas de português é: " + mediaPort / 5);
        System.out.println("O valor da média das notas de matemática é: " + mediaMat / 5);
        System.out.println("O aluno com a MAIOR nota de Matemática é o " + alunoMaiorMat + " Com o total de " + maiorMat);
        System.out.println("O aluno com a MENOR nota de Português é o " + alunoMenorPort + " Com o total de " + menorPort);
        
        
    }
    
}
