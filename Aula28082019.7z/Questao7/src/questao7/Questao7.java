package questao7;

import java.util.Scanner;

public class Questao7 {

    public static void main(String[] args) {
        // Apresente o maior entre dois números entre dois números.
          double num1, num2, num3, media = 0;
          
          Scanner entrada = new Scanner(System.in);
          
          System.out.println("Insira o primeiro número: ");
          num1 = entrada.nextDouble();
          
          System.out.println("Insira o primeiro número: ");
          num2 = entrada.nextDouble();
          
          System.out.println("Insira o primeiro número: ");
          num3 = entrada.nextDouble();
          
          entrada.close();
          
          media = (num1 + num2 + num3) / 3;
          
          System.out.println("O valor da divisão entre os dois números é: " + media);
    }
    
}
