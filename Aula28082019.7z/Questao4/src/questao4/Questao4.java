package questao4;

import java.util.Scanner;

public class Questao4 {

    public static void main(String[] args) {
        // Apresente a divisão entre dois números.
          int num1, num2, divisao;
          
          Scanner entrada = new Scanner(System.in);
          
          System.out.println("Insira o primeiro número: ");
          num1 = entrada.nextInt();
          
          System.out.println("Insira o primeiro número: ");
          num2 = entrada.nextInt();
          
          entrada.close();
          
          divisao =  num1 / num2;
          
          System.out.println("O valor da divisão entre os dois números é: " + divisao);
    }
    
}
