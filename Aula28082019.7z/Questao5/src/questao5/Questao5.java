package questao5;

import java.util.Scanner;

public class Questao5 {

    public static void main(String[] args) {
        // Apresente o maior entre dois números entre dois números.
          int num1, num2, maior = 0;
          
          Scanner entrada = new Scanner(System.in);
          
          System.out.println("Insira o primeiro número: ");
          num1 = entrada.nextInt();
          
          System.out.println("Insira o primeiro número: ");
          num2 = entrada.nextInt();
          
          entrada.close();
          
          if(num1 > num2){
              maior = num1;
          }
          if(num2 > num1){
              maior = num2;
          }else{
              System.out.println("Os números são iguais!");
          }
          System.out.println("O valor da divisão entre os dois números é: " + maior);
    }
    
}
