package questao2;

import java.util.Scanner;

public class Questao2 {

    
    public static void main(String[] args) {
          // Apresente o produto entre dois números.
          int num1, num2, produto;
          
          Scanner entrada = new Scanner(System.in);
          
          System.out.println("Insira o primeiro número: ");
          num1 = entrada.nextInt();
          
          System.out.println("Insira o primeiro número: ");
          num2 = entrada.nextInt();
          
          entrada.close();
          
          produto =  num1 * num2;
          
          System.out.println("O produto entre os dois números é: " + produto);
    }
    
}
