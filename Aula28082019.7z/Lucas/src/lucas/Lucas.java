package lucas;
import java.util.Scanner;


public class Lucas {

    
    public static void main(String[] args) {
          int num1, num2, num3, soma;
          
          Scanner entrada = new Scanner(System.in);
          
          System.out.println("Insira o primeiro número: ");
          num1 = entrada.nextInt();
          
          System.out.println("Insira o primeiro número: ");
          num2 = entrada.nextInt();
          
          System.out.println("Insira o primeiro número: ");
          num3 = entrada.nextInt();
          
          entrada.close();
          
          soma =  num1 + num2 + num3;
          
          System.out.println("A soma é: " + soma);
        
    }
    
}
