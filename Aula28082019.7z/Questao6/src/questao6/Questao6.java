package questao6;

import java.util.Scanner;

public class Questao6 {

    public static void main(String[] args) {
        // Apresente o maior entre dois números entre dois números.
          int num1, num2, num3, num4, num5, maior =0;
          
          Scanner entrada = new Scanner(System.in);
          
          System.out.println("Insira o primeiro número: ");
          num1 = entrada.nextInt();
          
          System.out.println("Insira o segundo número: ");
          num2 = entrada.nextInt();
          
          System.out.println("Insira o terceiro número: ");
          num3 = entrada.nextInt();
          
          System.out.println("Insira o quarto número: ");
          num4 = entrada.nextInt();
          
          System.out.println("Insira o quinto número: ");
          num5 = entrada.nextInt();
          
          entrada.close();
          
          if(num1 > num2 && num1 > num3 && num1 > num4 && num1 > num5){
              maior = num1;
          }
          if(num2 > num1 && num2 > num3 && num2 > num4 && num2 > num5){
              maior = num2;
          }
          if(num3 > num2 && num3 > num1 && num3 > num4 && num3 > num5){
              maior = num3;
          }
          if(num4 > num2 && num4 > num3 && num4 > num1 && num4 > num5){
              maior = num4;
          }
          if(num5 > num2 && num5 > num3 && num5 > num4 && num5 > num1){
              maior = num5;
          }
          else{
              System.out.println("Você destruiu o programa!");
          }
          
          System.out.println("O maior é: " + maior);
    }
    
}
