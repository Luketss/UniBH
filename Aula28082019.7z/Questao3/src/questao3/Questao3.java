package questao3;

import java.util.Scanner;

public class Questao3 {

    
    public static void main(String[] args) {
        // Apresente a subtração entre dois números.
          int num1, num2, subtracao;
          
          Scanner entrada = new Scanner(System.in);
          
          System.out.println("Insira o primeiro número: ");
          num1 = entrada.nextInt();
          
          System.out.println("Insira o primeiro número: ");
          num2 = entrada.nextInt();
          
          entrada.close();
          
          subtracao =  num1 - num2;
          
          System.out.println("O valor da subtração entre os dois números é: " + subtracao);
    }
    
}
